var searchData=
[
  ['exception',['Exception',['../classopencc_1_1_exception.html',1,'opencc']]]
];
