var searchData=
[
  ['cmdlineoutput',['CmdLineOutput',['../class_cmd_line_output.html',1,'']]],
  ['config',['Config',['../classopencc_1_1_config.html',1,'opencc']]],
  ['configtestbase',['ConfigTestBase',['../classopencc_1_1_config_test_base.html',1,'opencc']]],
  ['conversion',['Conversion',['../classopencc_1_1_conversion.html',1,'opencc']]],
  ['conversionchain',['ConversionChain',['../classopencc_1_1_conversion_chain.html',1,'opencc']]],
  ['convert',['Convert',['../classopencc_1_1_simple_converter.html#a0042dba7fe92bee2cadb4d7a8cbec929',1,'opencc::SimpleConverter::Convert(const std::string &amp;input) const'],['../classopencc_1_1_simple_converter.html#a3bc95485e6b8c5bca6b728f557efd98a',1,'opencc::SimpleConverter::Convert(const char *input) const'],['../classopencc_1_1_simple_converter.html#a63baff1214203c8835105b5167daba43',1,'opencc::SimpleConverter::Convert(const char *input, size_t length) const'],['../classopencc_1_1_simple_converter.html#ac9eb53d7dbecf687e0d43eaaf9bf2bd1',1,'opencc::SimpleConverter::Convert(const char *input, char *output) const'],['../classopencc_1_1_simple_converter.html#a63f5dbba323443bd42772d4c5c77b313',1,'opencc::SimpleConverter::Convert(const char *input, size_t length, char *output) const']]],
  ['converter',['Converter',['../classopencc_1_1_converter.html',1,'opencc']]]
];
