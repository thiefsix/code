var indexSectionsWithContent =
{
  0: "bcdefghijklmnoprstu",
  1: "bcdefhilmnopstu",
  2: "cfgijklmnoprst",
  3: "o",
  4: "o",
  5: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "typedefs",
  4: "groups",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Typedefs",
  4: "Modules",
  5: "Pages"
};

