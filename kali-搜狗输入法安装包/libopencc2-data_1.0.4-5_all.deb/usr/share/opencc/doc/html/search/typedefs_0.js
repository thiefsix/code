var searchData=
[
  ['opencc_5ft',['opencc_t',['../group__opencc__c__api.html#gaa08a1436fedc071dc6fc352c98a6ade9',1,'opencc.h']]]
];
