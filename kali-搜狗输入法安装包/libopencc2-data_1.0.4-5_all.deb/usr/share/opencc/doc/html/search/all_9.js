var searchData=
[
  ['keymaxlength',['KeyMaxLength',['../classopencc_1_1_darts_dict.html#a904ca485ce8de4c6981eba7d325f1ecd',1,'opencc::DartsDict::KeyMaxLength()'],['../classopencc_1_1_dict.html#a3510da98594e790c35e5b06198d99ff7',1,'opencc::Dict::KeyMaxLength()'],['../classopencc_1_1_dict_group.html#a0c7dc42939992a9797eacabaee3f3226',1,'opencc::DictGroup::KeyMaxLength()'],['../classopencc_1_1_text_dict.html#af067b048902791dec8df6ae72749b366',1,'opencc::TextDict::KeyMaxLength()']]]
];
