var searchData=
[
  ['lexicon',['Lexicon',['../classopencc_1_1_lexicon.html',1,'opencc']]]
];
