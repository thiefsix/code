var searchData=
[
  ['maxmatchsegmentation',['MaxMatchSegmentation',['../classopencc_1_1_max_match_segmentation.html',1,'opencc']]],
  ['multivaluedictentry',['MultiValueDictEntry',['../classopencc_1_1_multi_value_dict_entry.html',1,'opencc']]]
];
