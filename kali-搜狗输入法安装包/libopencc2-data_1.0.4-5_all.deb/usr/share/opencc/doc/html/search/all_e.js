var searchData=
[
  ['phraseextract',['PhraseExtract',['../classopencc_1_1_phrase_extract.html',1,'opencc']]],
  ['prevchar',['PrevChar',['../classopencc_1_1_u_t_f8_util.html#ab6031f3d1a95f66c51a142d5c2794614',1,'opencc::UTF8Util']]],
  ['prevcharlength',['PrevCharLength',['../classopencc_1_1_u_t_f8_util.html#a153a270ce21d855c07a7d5eba397da5e',1,'opencc::UTF8Util']]],
  ['ptrdictentry',['PtrDictEntry',['../classopencc_1_1_ptr_dict_entry.html',1,'opencc']]]
];
