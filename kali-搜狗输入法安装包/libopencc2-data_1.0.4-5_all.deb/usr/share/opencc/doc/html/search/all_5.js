var searchData=
[
  ['get',['Get',['../classopencc_1_1_optional.html#a29da7f8f497839c249e9353e95aff69a',1,'opencc::Optional']]],
  ['getlexicon',['GetLexicon',['../classopencc_1_1_darts_dict.html#aca8943b44e0052a8aa0951fa8a36f8e0',1,'opencc::DartsDict::GetLexicon()'],['../classopencc_1_1_dict.html#a5c7c7bb2a5c9fca9077233bd38d7a3dd',1,'opencc::Dict::GetLexicon()'],['../classopencc_1_1_dict_group.html#a0e86fd816d114f1af51c131f90b019c5',1,'opencc::DictGroup::GetLexicon()'],['../classopencc_1_1_text_dict.html#a4f7579b7dedb13ac2d620e125cf39d5b',1,'opencc::TextDict::GetLexicon()']]]
];
