var searchData=
[
  ['textdict',['TextDict',['../classopencc_1_1_text_dict.html',1,'opencc']]],
  ['textdicttestbase',['TextDictTestBase',['../classopencc_1_1_text_dict_test_base.html',1,'opencc']]]
];
