var searchData=
[
  ['filenotfound',['FileNotFound',['../classopencc_1_1_file_not_found.html',1,'opencc']]],
  ['filenotwritable',['FileNotWritable',['../classopencc_1_1_file_not_writable.html',1,'opencc']]]
];
